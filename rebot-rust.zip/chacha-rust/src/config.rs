use anyhow::Result;
use config::{Config, File};
use serde::{Deserialize, Serialize};
use std::sync::OnceLock;

static CONFIG: OnceLock<AppConfig> = OnceLock::new();

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AppConfig {
    pub server: ServerConfig,
    pub tt_robot: TTRobotConfig,
    pub paths: PathsConfig,
    pub logging: LoggingConfig,
    pub scheduler: SchedulerConfig,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ServerConfig {
    pub host: String,
    pub port: u16,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TTRobotConfig {
    pub app_id: String,
    pub app_secret: String,
    pub robot_id: String,
    pub host: String,
    pub upload_url: String,
    pub environment: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PathsConfig {
    pub root_dir: String,
    pub cache_dir: String,
    pub log_dir: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LoggingConfig {
    pub level: String,
    pub format: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SchedulerConfig {
    pub cookie_check: String,
}

impl AppConfig {
    pub fn load() -> Result<Self> {
        dotenvy::dotenv().ok();

        let config = Config::builder()
            .add_source(File::with_name("config.toml").required(false))
            .add_source(config::Environment::with_prefix("CHACHA"))
            .build()?;

        let app_config: AppConfig = config.try_deserialize()?;
        Ok(app_config)
    }

    pub fn global() -> &'static AppConfig {
        CONFIG.get().expect("Config not initialized")
    }

    pub fn init() -> Result<()> {
        let config = Self::load()?;
        CONFIG.set(config).map_err(|_| anyhow::anyhow!("Config already initialized"))?;
        Ok(())
    }
}

