use crate::error::{ChachaError, Result};
use once_cell::sync::Lazy;
use std::sync::RwLock;
use tracing::{error, info};

// 全局登录 token 存储
static LOGIN_TOKEN: Lazy<RwLock<Option<String>>> = Lazy::new(|| RwLock::new(None));

/// 设置登录 token
pub fn set_login_token(token: String) {
    let mut t = LOGIN_TOKEN.write().unwrap();
    *t = Some(token);
    info!("登录 token 已更新");
}

/// 获取登录 token
pub fn get_login_token() -> Option<String> {
    LOGIN_TOKEN.read().unwrap().clone()
}

/// 刷新登录状态
/// 
/// 当检测到 token 过期时，会调用此函数重新登录
pub async fn refresh_login() -> Result<()> {
    info!("开始重新登录...");
    
    // TODO: 实现具体的登录逻辑
    // 这里应该调用实际的登录 API，获取新的 token
    // 示例：
    // let new_token = call_login_api().await?;
    // set_login_token(new_token);
    
    // 临时实现：从环境变量读取
    if let Ok(token) = std::env::var("LOGIN_TOKEN") {
        set_login_token(token);
        info!("从环境变量重新加载 token 成功");
        Ok(())
    } else {
        error!("无法获取登录 token");
        Err(ChachaError::LoginError("无法获取登录 token".to_string()))
    }
}

/// 初始化登录状态
pub fn init_login() -> Result<()> {
    if let Ok(token) = std::env::var("LOGIN_TOKEN") {
        set_login_token(token);
        info!("登录 token 初始化成功");
        Ok(())
    } else {
        info!("未找到初始登录 token，将在需要时获取");
        Ok(())
    }
}

