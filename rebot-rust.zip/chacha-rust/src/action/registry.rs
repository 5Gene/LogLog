use crate::error::Result;
use crate::tt_robot::TTMsg;
use once_cell::sync::Lazy;
use regex::Regex;
use std::collections::BTreeMap;
use std::future::Future;
use std::pin::Pin;
use std::sync::{Arc, RwLock};
use tracing::{debug, info};

pub type ActionFn =
    Arc<dyn Fn(TTMsg) -> Pin<Box<dyn Future<Output = Result<()>> + Send>> + Send + Sync>;

#[derive(Clone)]
pub struct ActionInfo {
    pub pattern: Regex,
    pub desc: String,
    pub priority: i32,
    pub handler: ActionFn,
}

impl std::fmt::Debug for ActionInfo {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("ActionInfo")
            .field("pattern", &self.pattern.as_str())
            .field("desc", &self.desc)
            .field("priority", &self.priority)
            .finish()
    }
}

pub static ACTION_REGISTRY: Lazy<RwLock<BTreeMap<i32, Vec<ActionInfo>>>> =
    Lazy::new(|| RwLock::new(BTreeMap::new()));

pub fn register_action(action: ActionInfo) {
    let mut registry = ACTION_REGISTRY.write().unwrap();
    registry
        .entry(action.priority)
        .or_insert_with(Vec::new)
        .push(action.clone());
    info!(
        "Registered action: {} with priority {}",
        action.desc, action.priority
    );
}

pub fn list_actions() -> Vec<String> {
    let registry = ACTION_REGISTRY.read().unwrap();
    let mut descriptions = Vec::new();
    
    // Iterate in priority order (BTreeMap maintains sorted order)
    for (_priority, actions) in registry.iter() {
        for action in actions {
            descriptions.push(action.desc.clone());
        }
    }
    
    descriptions
}

pub async fn dispatch_action(text: &str, msg: TTMsg) -> Result<bool> {
    let registry = ACTION_REGISTRY.read().unwrap();
    
    // Iterate in priority order (lower priority number = higher priority)
    for (_priority, actions) in registry.iter() {
        for action in actions {
            if action.pattern.is_match(text) {
                debug!("Action matched: {} for text: {}", action.desc, text);
                
                // Clone the handler and msg to avoid lifetime issues
                let handler = action.handler.clone();
                let msg_clone = msg.clone();
                
                // Spawn async task to handle the action
                tokio::spawn(async move {
                    match handler(msg_clone).await {
                        Ok(_) => info!("Action completed successfully"),
                        Err(e) => tracing::error!("Action failed: {}", e),
                    }
                });
                
                return Ok(true);
            }
        }
    }
    
    debug!("No action matched for text: {}", text);
    Ok(false)
}

// Note: action registration is now handled by the #[action] proc macro in chacha-macros
// The macro automatically registers actions at program startup using the ctor crate

