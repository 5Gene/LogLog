use thiserror::Error;

#[derive(Error, Debug)]
pub enum ChachaError {
    #[error("HTTP error: {0}")]
    Http(#[from] reqwest::Error),

    #[error("JSON error: {0}")]
    Json(#[from] serde_json::Error),

    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),

    #[error("Regex error: {0}")]
    Regex(#[from] regex::Error),

    #[error("TT Robot API error: {0}")]
    TTRobotApi(String),

    #[error("Action not found for input: {0}")]
    ActionNotFound(String),

    #[error("Configuration error: {0}")]
    Config(#[from] config::ConfigError),

    #[error("Login error: {0}")]
    LoginError(String),

    #[error("Token expired or invalid")]
    TokenError,

    #[error("{0}")]
    Custom(String),
}

pub type Result<T> = std::result::Result<T, ChachaError>;

