use chacha::{business, config::AppConfig, server, action};
use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt, EnvFilter};

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    // 1. 初始化日志系统
    tracing_subscriber::registry()
        .with(
            EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| "chacha=info,tower_http=debug".into()),
        )
        .with(tracing_subscriber::fmt::layer())
        .init();

    tracing::info!("========================================");
    tracing::info!("Chacha 机器人启动中...");
    tracing::info!("========================================");

    // 2. 加载配置
    AppConfig::init()?;
    let config = AppConfig::global().clone();
    
    tracing::info!("✓ 配置加载成功");
    tracing::info!("  - 服务地址: {}:{}", config.server.host, config.server.port);
    tracing::info!("  - TT机器人ID: {}", config.tt_robot.robot_id);
    tracing::info!("  - 环境: {}", config.tt_robot.environment);

    // 3. 初始化登录状态
    action::auth::init_login()?;
    tracing::info!("✓ 登录状态初始化完成");

    // 4. 导入业务模块（触发自动注册）
    // 通过导入模块，#[action] 宏会自动通过 ctor 注册所有 actions
    let _ = business::actions::git_log;
    let _ = business::actions::get_phone_log;
    let _ = business::actions::log_read;

    // 5. 列出已注册的 actions
    let actions = chacha::action::list_actions();
    tracing::info!("✓ 已注册 {} 个业务处理器:", actions.len());
    for (idx, action_desc) in actions.iter().enumerate() {
        tracing::info!("  {}. {}", idx + 1, action_desc);
    }

    // 6. 获取本机 IP 并输出服务信息
    tracing::info!("========================================");
    if let Ok(hostname) = hostname::get() {
        if let Ok(hostname_str) = hostname.into_string() {
            tracing::info!("主机名: {}", hostname_str);
            
            // 尝试解析 IP
            if let Ok(addrs) = tokio::net::lookup_host(format!("{}:0", hostname_str)).await {
                for addr in addrs {
                    if addr.is_ipv4() {
                        tracing::info!("服务地址: http://{}:{}", addr.ip(), config.server.port);
                        tracing::info!("健康检查: http://{}:{}/health", addr.ip(), config.server.port);
                        tracing::info!("文件下载: http://{}:{}/file?path=<文件路径>", addr.ip(), config.server.port);
                        break;
                    }
                }
            }
        }
    }
    tracing::info!("服务监听: {}:{}", config.server.host, config.server.port);
    tracing::info!("========================================");

    // 7. 启动 HTTP 服务器
    server::start_server(config).await?;

    Ok(())
}

