use crate::action::dispatch_action;
use crate::config::AppConfig;
use crate::error::Result;
use crate::tt_robot::{TTMsg, TTRobotClient, TTWebhook};
use chrono::{DateTime, Local};
use tracing::{debug, info};

pub struct MessageDispatcher {
    tt_client: TTRobotClient,
}

impl MessageDispatcher {
    pub fn new(config: AppConfig) -> Self {
        let tt_client = TTRobotClient::new(config);
        Self { tt_client }
    }

    pub async fn dispatch(&self, webhook: TTWebhook) -> Result<()> {
        let msg = match TTMsg::from_webhook(webhook) {
            Some(msg) => msg,
            None => {
                debug!("Ignored inefficient message");
                return Ok(());
            }
        };

        if !msg.is_efficient {
            return Ok(());
        }

        if msg.is_group {
            self.handle_group_message(msg).await?;
        } else {
            self.handle_direct_message(msg).await?;
        }

        Ok(())
    }

    async fn handle_group_message(&self, msg: TTMsg) -> Result<()> {
        let dt: DateTime<Local> = DateTime::from_timestamp(msg.send_time / 1000, 0)
            .unwrap_or_else(|| Local::now().into())
            .into();
        let formatted_time = dt.format("%Y-%m-%d %H:%M:%S").to_string();

        // Skip messages that are replies to our own messages
        if let Some(ref reply_content) = msg.reply_content {
            if reply_content.contains("绑定信息查询结果")
                || (reply_content.contains("反馈ID:") && reply_content.contains("耗时："))
            {
                info!("{} 引用查查返回的日志结果，忽略", msg.sender.user_name);
                return Ok(());
            }
        }

        let text = if let Some(ref reply_content) = msg.reply_content {
            info!(
                "{}: 机器人收到:{} 在群聊：{} 回复:{} 的消息",
                formatted_time,
                msg.sender.user_name,
                msg.group_name.as_deref().unwrap_or("Unknown"),
                reply_content
            );
            format!("{} ${}", reply_content, msg.text.as_deref().unwrap_or(""))
        } else if let Some(ref text) = msg.text {
            info!(
                "{}: 机器人收到:{} 在群聊：{} 发来的消息:{}",
                formatted_time,
                msg.sender.user_name,
                msg.group_name.as_deref().unwrap_or("Unknown"),
                text
            );
            text.trim().to_string()
        } else {
            return Ok(());
        };

        if text.is_empty() {
            return Ok(());
        }

        // Handle "help" command
        if text == "help" {
            self.send_help_group(&msg).await?;
            return Ok(());
        }

        // Try to dispatch to action handlers
        let matched = dispatch_action(&text, msg.clone()).await?;

        if !matched {
            self.send_not_supported_group(&msg).await?;
        }

        Ok(())
    }

    async fn handle_direct_message(&self, msg: TTMsg) -> Result<()> {
        let dt: DateTime<Local> = DateTime::from_timestamp(msg.send_time / 1000, 0)
            .unwrap_or_else(|| Local::now().into())
            .into();
        let formatted_time = dt.format("%Y-%m-%d %H:%M:%S").to_string();

        if msg.is_file {
            info!(
                "{}：机器人收到:{} 发来的私聊文件 {}",
                formatted_time,
                msg.sender.user_name,
                msg.file_name.as_deref().unwrap_or("Unknown")
            );

            let file_name = msg.file_name.as_deref().unwrap_or("");
            let matched = dispatch_action(file_name, msg.clone()).await?;

            if !matched {
                self.tt_client
                    .send_one(&msg.sender.user_code, "文件支持日志解析，格式为.zip压缩包，.log和.dog3")
                    .await?;
            }

            return Ok(());
        }

        let text = msg.text.as_deref().unwrap_or("").trim();
        info!(
            "{}：机器人收到:{} 发来的私聊消息 {}",
            formatted_time, msg.sender.user_name, text
        );

        if text.is_empty() {
            return Ok(());
        }

        // Handle "help" command
        if text == "help" {
            self.send_help_direct(&msg).await?;
            return Ok(());
        }

        // Try to dispatch to action handlers
        let matched = dispatch_action(text, msg.clone()).await?;

        if !matched {
            self.send_not_supported_direct(&msg).await?;
        }

        Ok(())
    }

    async fn send_help_group(&self, msg: &TTMsg) -> Result<()> {
        let capabilities = crate::action::list_actions();
        let help_text = format!("\n支持查询的关键字有：\n{}", capabilities.join("\n"));

        if let (Some(group_id), Some(message_id)) = (&msg.group_id, &msg.message_id) {
            self.tt_client.reply(group_id, message_id, &help_text).await?;
        }

        Ok(())
    }

    async fn send_help_direct(&self, msg: &TTMsg) -> Result<()> {
        let capabilities = crate::action::list_actions();
        let help_text = format!(
            "查询手表的绑定记录关键字：手机号，手表IMEI，手表MAC，用户SSOID，手表SN (空格隔开同时查多个)\n\n支持查询的关键字有：\n{}",
            capabilities.join("\n")
        );

        self.tt_client.send_one(&msg.sender.user_code, &help_text).await?;
        Ok(())
    }

    async fn send_not_supported_group(&self, msg: &TTMsg) -> Result<()> {
        let help = "机器人为穿戴事业部内部使用\n可以查询手机日志，日志反馈ID发给机器人即可，支持W和OLC格式的反馈ID，空格或逗号隔开可以连续查多个，默认查询国内手机日志，海外日志查询格式：印度W..或 新加坡W..";

        if let (Some(group_id), Some(message_id)) = (&msg.group_id, &msg.message_id) {
            self.tt_client.reply(group_id, message_id, help).await?;
        }

        Ok(())
    }

    async fn send_not_supported_direct(&self, msg: &TTMsg) -> Result<()> {
        let help = "机器人为穿戴事业部内部使用\n可以查询手机日志，日志反馈ID发给机器人即可，支持W和OLC格式的反馈ID，空格或逗号隔开可以连续查多个，默认查询国内手机日志，海外日志查询格式：印度W..或 新加坡W..";

        self.tt_client.send_one(&msg.sender.user_code, help).await?;
        Ok(())
    }
}

