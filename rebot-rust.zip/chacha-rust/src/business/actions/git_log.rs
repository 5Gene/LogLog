use chacha_macros::action;
use crate::error::Result;
use crate::tt_robot::TTMsg;
use std::process::Command;
use std::path::Path;
use tempfile::NamedTempFile;
use tokio::fs;
use tracing::{error, info};

#[action(r"loggit .*", "【loggit 37d992a wsw/master】返回指定分支指定节点到当前的git log", -1)]
async fn git_log_action(msg: TTMsg) -> Result<()> {
    let text = msg.text.as_deref().unwrap_or("");
    let parts: Vec<&str> = text.split_whitespace().collect();

    if parts.len() < 3 {
        let tt_client = crate::tt_robot::TTRobotClient::new(crate::config::AppConfig::global().clone());
        tt_client
            .send_one(&msg.sender.user_code, "支持的格式为：loggit 37d992a wsw/master_overseas")
            .await?;
        return Ok(());
    }

    let hash = parts[1];
    let branch = parts[2];

    info!("Processing git log: hash={}, branch={}", hash, branch);

    // TODO: Make this configurable
    let health_project = r"D:\0work\0gerrit\Health\fitness\Health";
    
    match exec_git_log(health_project, hash, branch).await {
        Ok(log_file) => {
            let tt_client = crate::tt_robot::TTRobotClient::new(crate::config::AppConfig::global().clone());
            tt_client.send_one_file(&msg.sender.user_code, &log_file).await?;
        }
        Err(e) => {
            error!("Failed to execute git log: {}", e);
            let tt_client = crate::tt_robot::TTRobotClient::new(crate::config::AppConfig::global().clone());
            tt_client
                .send_one(&msg.sender.user_code, &format!("获取 git log 失败: {}", e))
                .await?;
        }
    }

    Ok(())
}

async fn exec_git_log(project_dir: &str, hash: &str, branch: &str) -> Result<String> {
    let project_path = Path::new(project_dir);
    
    if !project_path.exists() {
        return Err(crate::error::ChachaError::Custom(
            format!("Project directory does not exist: {}", project_dir)
        ));
    }

    // Execute git commands
    run_git_command(project_path, &["reset", "--hard"])?;
    run_git_command(project_path, &["checkout", branch])?;
    run_git_command(project_path, &["fetch", "origin"])?;
    run_git_command(project_path, &["reset", "--hard", &format!("origin/{}", branch)])?;

    // Generate git log
    let log_output = Command::new("git")
        .current_dir(project_path)
        .args(&["log", &format!("{}..remotes/origin/{}", hash, branch)])
        .output()
        .map_err(|e| crate::error::ChachaError::Custom(format!("Failed to execute git log: {}", e)))?;

    if !log_output.status.success() {
        return Err(crate::error::ChachaError::Custom(
            format!("Git log command failed: {}", String::from_utf8_lossy(&log_output.stderr))
        ));
    }

    // Save to temporary file
    let mut temp_file = NamedTempFile::new()?;
    use std::io::Write;
    temp_file.write_all(&log_output.stdout)?;
    
    let cache_dir = Path::new(&crate::config::AppConfig::global().paths.cache_dir);
    fs::create_dir_all(cache_dir).await?;
    
    let cache_file = cache_dir.join("git_log.log");
    fs::write(&cache_file, log_output.stdout).await?;

    Ok(cache_file.to_string_lossy().to_string())
}

fn run_git_command(project_path: &Path, args: &[&str]) -> Result<()> {
    let output = Command::new("git")
        .current_dir(project_path)
        .args(args)
        .output()
        .map_err(|e| crate::error::ChachaError::Custom(format!("Failed to execute git: {}", e)))?;

    if !output.status.success() {
        return Err(crate::error::ChachaError::Custom(
            format!("Git command failed: {} - {}", args.join(" "), String::from_utf8_lossy(&output.stderr))
        ));
    }

    Ok(())
}

