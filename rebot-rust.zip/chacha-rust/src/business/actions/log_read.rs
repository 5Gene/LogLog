use chacha_macros::action;
use crate::error::Result;
use crate::tt_robot::TTMsg;
use regex::Regex;
use std::path::Path;
use std::process::Command;
use tokio::fs;
use tracing::{error, info};

#[action(r".*\.(zip|log|dog\d)$", "【zip,log,dog1,dog2,dog3】解密这些日志打捞格式的文件")]
async fn log_read_action(msg: TTMsg) -> Result<()> {
    if msg.is_group {
        let tt_client = crate::tt_robot::TTRobotClient::new(crate::config::AppConfig::global().clone());
        if let (Some(group_id), Some(message_id)) = (msg.group_id, msg.message_id) {
            tt_client.reply(&group_id, &message_id, "NOT SUPPORT!!").await?;
        }
        return Ok(());
    }

    if !msg.is_file {
        return Ok(());
    }

    let file_id = msg.file_id.as_ref().ok_or_else(|| {
        crate::error::ChachaError::Custom("No file ID".to_string())
    })?;
    let file_name = msg.file_name.as_ref().ok_or_else(|| {
        crate::error::ChachaError::Custom("No file name".to_string())
    })?;

    info!("开始解密日志文件：{}", file_name);

    let tt_client = crate::tt_robot::TTRobotClient::new(crate::config::AppConfig::global().clone());

    // Download file
    let (downloaded_name, file_path) = match tt_client.download_file(file_id, &msg.sender.user_code).await {
        Ok(f) => f,
        Err(e) => {
            error!("Failed to download file: {}", e);
            tt_client.send_one(&msg.sender.user_code, &format!("文件下载失败: {}", e)).await?;
            return Ok(());
        }
    };

    // Decrypt log
    match decrypt_log(&file_path, &downloaded_name, &msg.sender.user_code).await {
        Ok(decrypted_path) => {
            let file_size = fs::metadata(&decrypted_path).await?.len();
            info!("日志解密成功，文件大小: {}", file_size);

            if file_size < 100 * 1024 * 1024 {
                // Less than 100MB, send via TT
                tt_client.send_one_file(&msg.sender.user_code, &decrypted_path).await?;
            } else {
                // Generate download URL
                let download_url = format!(
                    "http://{}:{}/file?path={}",
                    crate::config::AppConfig::global().server.host,
                    crate::config::AppConfig::global().server.port,
                    urlencoding::encode(&decrypted_path)
                );
                tt_client
                    .send_one(&msg.sender.user_code, &format!("点击连接下载文件：\n{}", download_url))
                    .await?;
            }
        }
        Err(e) => {
            error!("Failed to decrypt log: {}", e);
            tt_client
                .send_one(&msg.sender.user_code, &format!("解密失败: {}", e))
                .await?;
        }
    }

    Ok(())
}

async fn decrypt_log(file_path: &str, file_name: &str, user_code: &str) -> Result<String> {
    let config = crate::config::AppConfig::global();
    let cache_dir = Path::new(&config.paths.cache_dir).join(user_code);
    fs::create_dir_all(&cache_dir).await?;

    let translate_path = cache_dir.join(format!("{}_{}.txt", user_code, file_name));
    let jar_path = Path::new(&config.paths.root_dir).join("business/log-prase-1.0-SNAPSHOT.jar");

    // Determine action type based on file extension
    let action_type = if file_name.ends_with(".zip") {
        "2"
    } else if file_name.ends_with(".log") {
        "1"
    } else {
        "0"
    };

    // Execute Java command
    // java -jar log-prase-1.0-SNAPSHOT.jar <input> <output> <action>
    let output = Command::new("java")
        .args(&[
            "-jar",
            jar_path.to_str().unwrap(),
            file_path,
            translate_path.to_str().unwrap(),
            action_type,
        ])
        .output()
        .map_err(|e| crate::error::ChachaError::Custom(format!("Failed to execute java: {}", e)))?;

    let stderr = String::from_utf8_lossy(&output.stderr);
    if !stderr.is_empty() && stderr.len() > 1 {
        return Err(crate::error::ChachaError::Custom(format!("解密失败：{}", stderr)));
    }

    let stdout = String::from_utf8_lossy(&output.stdout);
    if stdout.contains("[main] ERROR com") {
        return Err(crate::error::ChachaError::Custom(format!("解密失败：{}", stdout)));
    }

    Ok(translate_path.to_string_lossy().to_string())
}

