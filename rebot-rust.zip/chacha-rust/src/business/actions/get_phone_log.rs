use chacha_macros::{action, retry_on_token_error};
use crate::error::{ChachaError, Result};
use crate::tt_robot::TTMsg;
use chrono::{DateTime, Utc};
use regex::Regex;
use reqwest::Client;
use serde::{Deserialize, Serialize};
use serde_json::json;
use std::time::Instant;
use tracing::{error, info};

#[derive(Debug, Deserialize)]
struct FeedbackResponse {
    code: i32,
    data: Option<FeedbackData>,
    message: Option<String>,
}

#[derive(Debug, Deserialize)]
struct FeedbackData {
    list: Option<Vec<FeedbackDetail>>,
    #[serde(flatten)]
    detail: Option<Box<FeedbackDetail>>,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct FeedbackDetail {
    feedback_id: String,
    brand: String,
    model: String,
    ota_version: String,
    country: String,
    province: String,
    description: String,
    log_poseidon_url: Option<String>,
    work_item_id: Option<String>,
    user_type: Option<i32>,
    contact_num: String,
    auid: String,
    recent_time: i64,
}

#[action(r".*?[w|W|OLC|ocl]\d+.*?", "【W..】捞取W开头反馈ID的手机系统日志")]
async fn phone_log_action(msg: TTMsg) -> Result<()> {
    let text = msg.text.as_deref().unwrap_or("");

    // Check if this is a reply to our own message
    if let Some(ref reply_content) = msg.reply_content {
        if reply_content.contains("耗时") && reply_content.contains("日志下载地址") {
            info!("{} 引用查查返回的日志结果，忽略", msg.sender.user_name);
            return Ok(());
        }
    }

    // Extract feedback IDs
    let re = Regex::new(r"((?:w|W|OLC|olc)\d{18,20}\b)+")?;
    let feedback_ids: Vec<&str> = re
        .find_iter(text)
        .map(|m| m.as_str())
        .collect();

    if feedback_ids.is_empty() {
        let tt_client = crate::tt_robot::TTRobotClient::new(crate::config::AppConfig::global().clone());
        send_msg(&tt_client, &msg, "反馈ID格式不对，长度不正确？，手机日志支持同时查询多个日志,空格隔开即可").await?;
        return Ok(());
    }

    for fid in feedback_ids {
        match get_phone_log("logkit.oppoer.me", fid).await {
            Ok(result) => {
                let tt_client = crate::tt_robot::TTRobotClient::new(crate::config::AppConfig::global().clone());
                send_msg(&tt_client, &msg, &result).await?;
            }
            Err(e) => {
                error!("Failed to get phone log for {}: {}", fid, e);
                let tt_client = crate::tt_robot::TTRobotClient::new(crate::config::AppConfig::global().clone());
                let error_msg = if matches!(e, ChachaError::TokenError) {
                    format!("登录失败, 或者联系开发者\nhttp://logkit.oppoer.me/feedback")
                } else {
                    e.to_string()
                };
                send_msg(&tt_client, &msg, &error_msg).await?;
            }
        }
    }

    Ok(())
}

async fn send_msg(tt_client: &crate::tt_robot::TTRobotClient, msg: &TTMsg, text: &str) -> Result<()> {
    if msg.is_group {
        if let (Some(group_id), Some(message_id)) = (&msg.group_id, &msg.message_id) {
            tt_client.reply(group_id, message_id, text).await?;
        }
    } else {
        tt_client.send_one(&msg.sender.user_code, text).await?;
    }
    Ok(())
}

#[retry_on_token_error]
async fn get_phone_log(host: &str, feedback_id: &str) -> Result<String> {
    let start_time = Instant::now();

    let data = if feedback_id.starts_with('W') || feedback_id.starts_with('w') {
        req_w_log_inner(host, feedback_id).await?
    } else {
        req_olc_log_inner(host, feedback_id).await?
    };

    let detail = match data {
        Some(d) => d,
        None => {
            return Ok(format!(
                "没查询到数据(海外日志查询格式(印度W..|新加坡W..)\n如果是刚提交的反馈可以晚点再试试\n\n反馈ID: {}\nhttps://{}/feedback",
                feedback_id, host
            ));
        }
    };

    let user_types = [
        "普通用户",
        "内测用户",
        "公测用户",
        "测试先锋",
        "升级尝鲜",
        "维修工程师",
        "临时上传",
        "临时上传",
    ];

    let user_type = detail
        .user_type
        .and_then(|t| user_types.get(t as usize))
        .unwrap_or(&"普通用户");

    let bug_url = detail
        .work_item_id
        .as_ref()
        .map(|id| format!("https://noah.myoas.com/micro-app/agile-dms/detail?workItemId={}", id))
        .unwrap_or_else(|| "None".to_string());

    let dt: DateTime<Utc> = DateTime::from_timestamp(detail.recent_time / 1000, 0)
        .unwrap_or_else(Utc::now);
    let str_time = dt.format("%Y-%m-%d %H:%M:%S").to_string();

    let elapsed = start_time.elapsed();

    if detail.log_poseidon_url.is_none() {
        return Ok(format!(
            "{}\n\n日志文件没转存到波塞冬没下载地址，请通过网页查询，或者晚些重试\nhttps://{}/feedback",
            detail.description, host
        ));
    }

    Ok(format!(
        "耗时：{:.2}s
时间: {}
反馈ID: {}
品牌: {}
机型: {}
版本号：{}
反馈国家: {}
反馈地区: {}
用户类型: {}
联系方式: {}
AUID: {}
日志下载地址: {}
BugId: {}
缺陷地址: {}
{}",
        elapsed.as_secs_f64(),
        str_time,
        detail.feedback_id,
        detail.brand,
        detail.model,
        detail.ota_version,
        detail.country,
        detail.province,
        user_type,
        detail.contact_num,
        detail.auid,
        detail.log_poseidon_url.as_deref().unwrap_or("None"),
        detail.work_item_id.as_deref().unwrap_or("None"),
        bug_url,
        detail.description
    ))
}

#[retry_on_token_error]
async fn req_w_log_inner(host: &str, feedback_id: &str) -> Result<Option<FeedbackDetail>> {
    info!("Requesting W log: {}", feedback_id);

    let url = format!(
        "https://{}/stage-api/web/problem/feedback/getFeedbackDetail?feedbackId={}",
        host, feedback_id
    );

    // TODO: Add proper authentication with token
    let client = Client::new();
    let response = client
        .get(&url)
        .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
        .header("Accept", "application/json")
        .send()
        .await?;

    let response_text = response.text().await?;
    info!("W log response: {}", response_text);

    let feedback_response: FeedbackResponse = serde_json::from_str(&response_text)?;

    if feedback_response.code == 20001 {
        return Err(ChachaError::TokenError);
    }

    Ok(feedback_response.data.and_then(|d| d.detail.map(|b| *b)))
}

#[retry_on_token_error]
async fn req_olc_log_inner(host: &str, feedback_id: &str) -> Result<Option<FeedbackDetail>> {
    info!("Requesting OLC log: {}", feedback_id);

    let url = format!("https://{}/stage-api/web/problem/feedback/getInfoList", host);

    let data = json!({
        "feedbackStartTime": "",
        "feedbackEndTime": "",
        "receiveFormStartTime": "",
        "receiveFormEndTime": "",
        "errorTypeList": [],
        "feedbackSchedule": [],
        "keyWord": "",
        "reproduceRate": "",
        "handleStartTime": "",
        "handleEndTime": "",
        "osVersion": [],
        "userType": [],
        "modelList": [],
        "auid": "",
        "brand": "",
        "labelIds": [],
        "country": "",
        "province": "",
        "pageNum": 1,
        "pageSize": 1,
        "sourceType": "phone",
        "otaVersion": "",
        "logPlatform": "",
        "extFeedbackId": feedback_id,
        "channelId": "",
        "softwareVersionNo": "",
        "fid": ""
    });

    // TODO: Add proper authentication with token
    let client = Client::new();
    let response = client
        .post(&url)
        .header("Content-Type", "application/json")
        .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
        .json(&data)
        .send()
        .await?;

    let response_text = response.text().await?;
    info!("OLC log response: {}", response_text);

    let feedback_response: FeedbackResponse = serde_json::from_str(&response_text)?;

    if feedback_response.code == 20001 {
        return Err(ChachaError::TokenError);
    }

    Ok(feedback_response
        .data
        .and_then(|d| d.list.and_then(|mut list| list.pop())))
}

