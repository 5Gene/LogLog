use axum::{
    extract::Query,
    http::StatusCode,
    response::{IntoResponse, Json, Response},
    routing::{get, post},
    Router,
};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use tokio::fs::File;
use tokio_util::io::ReaderStream;
use tower_http::trace::TraceLayer;
use tracing::info;

use crate::config::AppConfig;
use crate::dispatcher::MessageDispatcher;
use crate::tt_robot::TTWebhook;

pub async fn start_server(config: AppConfig) -> anyhow::Result<()> {
    let addr = format!("{}:{}", config.server.host, config.server.port);
    info!("Starting server on {}", addr);

    let dispatcher = MessageDispatcher::new(config.clone());

    let app = Router::new()
        .route("/listen", post(handle_tt_webhook))
        .route("/file", get(handle_file_download))
        .route("/tt", get(handle_tt_proxy))
        .route("/health", get(health_check))
        .layer(TraceLayer::new_for_http())
        .with_state(AppState { dispatcher, config });

    let listener = tokio::net::TcpListener::bind(&addr).await?;
    info!("Server listening on {}", addr);

    axum::serve(listener, app).await?;

    Ok(())
}

#[derive(Clone)]
struct AppState {
    dispatcher: MessageDispatcher,
    config: AppConfig,
}

async fn health_check() -> &'static str {
    "OK"
}

async fn handle_tt_webhook(
    axum::extract::State(state): axum::extract::State<AppState>,
    Json(webhook): Json<TTWebhook>,
) -> Result<Json<EmptyResponse>, AppError> {
    info!("Received TT webhook");

    tokio::spawn(async move {
        if let Err(e) = state.dispatcher.dispatch(webhook).await {
            tracing::error!("Failed to dispatch message: {}", e);
        }
    });

    Ok(Json(EmptyResponse {}))
}

#[derive(Debug, Serialize)]
struct EmptyResponse {}

#[derive(Debug, Deserialize)]
struct FileQuery {
    path: String,
}

async fn handle_file_download(
    Query(params): Query<FileQuery>,
) -> Result<Response, AppError> {
    let file_path = &params.path;
    
    let file = File::open(file_path).await.map_err(|e| {
        AppError::NotFound(format!("File not found: {}", e))
    })?;

    let stream = ReaderStream::new(file);
    let body = axum::body::Body::from_stream(stream);

    let file_name = std::path::Path::new(file_path)
        .file_name()
        .and_then(|n| n.to_str())
        .unwrap_or("download");

    let headers = [
        ("Content-Type", "application/octet-stream"),
        ("Content-Disposition", &format!("attachment; filename=\"{}\"", file_name)),
    ];

    Ok((headers, body).into_response())
}

#[derive(Debug, Deserialize)]
struct TTProxyQuery {
    who: String,
    msg: String,
}

async fn handle_tt_proxy(
    axum::extract::State(state): axum::extract::State<AppState>,
    Query(params): Query<TTProxyQuery>,
) -> Result<Json<HashMap<String, String>>, AppError> {
    info!("TT proxy: send [{}] to {}", params.msg, params.who);

    let tt_client = crate::tt_robot::TTRobotClient::new(state.config);
    tt_client.send_one(&params.who, &params.msg).await?;

    let mut response = HashMap::new();
    response.insert("who".to_string(), params.who);
    response.insert("msg".to_string(), params.msg);

    Ok(Json(response))
}

// Error handling
struct AppError(anyhow::Error);

impl AppError {
    fn NotFound(msg: String) -> Self {
        AppError(anyhow::anyhow!(msg))
    }
}

impl IntoResponse for AppError {
    fn into_response(self) -> Response {
        tracing::error!("Application error: {}", self.0);
        (
            StatusCode::INTERNAL_SERVER_ERROR,
            Json(serde_json::json!({
                "error": self.0.to_string()
            })),
        )
            .into_response()
    }
}

impl<E> From<E> for AppError
where
    E: Into<anyhow::Error>,
{
    fn from(err: E) -> Self {
        Self(err.into())
    }
}

