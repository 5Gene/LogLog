use crate::config::AppConfig;
use crate::error::{ChachaError, Result};
use crate::tt_robot::models::*;
use base64::{engine::general_purpose, Engine};
use chrono::Utc;
use hmac::{Hmac, Mac};
use rand::Rng;
use reqwest::{header, multipart, Client};
use serde_json::json;
use sha1::Sha1;
use std::path::Path;
use tokio::fs;
use tracing::{debug, info};

type HmacSha1 = Hmac<Sha1>;

pub struct TTRobotClient {
    client: Client,
    config: AppConfig,
}

impl TTRobotClient {
    pub fn new(config: AppConfig) -> Self {
        let client = Client::builder()
            .cookie_store(true)
            .build()
            .expect("Failed to create HTTP client");

        Self { client, config }
    }

    fn sign(&self, method: &str, timestamp: i64, nonce: &str, url: &str) -> String {
        let plain_text = format!(
            "{}&{}&{}&{}&{}&{}",
            method.to_uppercase(),
            self.config.tt_robot.host,
            url,
            self.config.tt_robot.app_id,
            timestamp,
            nonce
        );

        let mut mac = HmacSha1::new_from_slice(self.config.tt_robot.app_secret.as_bytes())
            .expect("HMAC can take key of any size");
        mac.update(plain_text.as_bytes());
        let result = mac.finalize();
        general_purpose::STANDARD.encode(result.into_bytes())
    }

    fn full_url(&self, path: &str) -> String {
        format!("https://{}{}", self.config.tt_robot.host, path)
    }

    async fn request<T>(
        &self,
        method: &str,
        url: &str,
        body: Option<serde_json::Value>,
    ) -> Result<TTResponse<T>>
    where
        T: serde::de::DeserializeOwned,
    {
        let timestamp = Utc::now().timestamp();
        let nonce = rand::thread_rng().gen_range(100000..999999).to_string();
        let signature = self.sign(method, timestamp, &nonce, url);

        let mut headers = header::HeaderMap::new();
        headers.insert(
            header::CONTENT_TYPE,
            header::HeaderValue::from_static("application/json"),
        );
        headers.insert("appid", header::HeaderValue::from_str(&self.config.tt_robot.app_id)?);
        headers.insert("nonce", header::HeaderValue::from_str(&nonce)?);
        headers.insert("sign", header::HeaderValue::from_str(&signature)?);
        headers.insert("timestamp", header::HeaderValue::from_str(&timestamp.to_string())?);
        headers.insert("signversion", header::HeaderValue::from_static("2.0.0"));

        if self.config.tt_robot.environment != "release" {
            headers.insert("envid", header::HeaderValue::from_static("UAT"));
        }

        let full_url = self.full_url(url);
        debug!("TT Robot request: {} {}", method, full_url);

        let request_builder = match method.to_uppercase().as_str() {
            "GET" => self.client.get(&full_url),
            "POST" => self.client.post(&full_url),
            _ => return Err(ChachaError::Custom(format!("Unsupported method: {}", method))),
        };

        let request_builder = request_builder.headers(headers);

        let response = if let Some(body) = body {
            debug!("Request body: {}", serde_json::to_string(&body)?);
            request_builder.json(&body).send().await?
        } else {
            request_builder.send().await?
        };

        let response_text = response.text().await?;
        debug!("Response: {}", response_text);

        let tt_response: TTResponse<T> = serde_json::from_str(&response_text)?;
        
        // Check for token error
        if tt_response.code == 20001 {
            return Err(ChachaError::TokenError);
        }

        Ok(tt_response)
    }

    pub async fn send_text(&self, who: &str, msg: &str, receive_type: &str) -> Result<()> {
        info!("Sending text to {}: {}", who, msg);

        let body = json!({
            "msg": {
                "text": msg
            },
            "from": {
                "pub": self.config.tt_robot.robot_id
            },
            "to": {
                "receiveId": who,
                "receiveType": receive_type
            },
            "type": 2
        });

        let _response: TTResponse<serde_json::Value> =
            self.request("POST", "/oppo-mtp/oppo-robot/messages/send", Some(body)).await?;

        Ok(())
    }

    pub async fn send_one(&self, who: &str, msg: &str) -> Result<()> {
        self.send_text(who, msg, "1").await
    }

    pub async fn send_group(&self, group_id: &str, msg: &str) -> Result<()> {
        self.send_text(group_id, msg, "2").await
    }

    pub async fn reply(&self, group_id: &str, message_id: &str, msg: &str) -> Result<()> {
        info!("Replying to message {} in group {}: {}", message_id, group_id, msg);

        let body = json!({
            "msg": {
                "text": msg
            },
            "from": {
                "pub": self.config.tt_robot.robot_id
            },
            "groupId": group_id,
            "messageId": message_id,
            "type": 2
        });

        let _response: TTResponse<serde_json::Value> =
            self.request("POST", "/oppo-mtp/oppo-robot/messages/reply", Some(body)).await?;

        Ok(())
    }

    pub async fn upload_file<P: AsRef<Path>>(&self, file_path: P) -> Result<UploadFileResponse> {
        let file_path = file_path.as_ref();
        let file_name = file_path
            .file_name()
            .and_then(|n| n.to_str())
            .ok_or_else(|| ChachaError::Custom("Invalid file name".to_string()))?;

        // Get upload token
        let token_response: TTResponse<String> =
            self.request("GET", "/oppo-mtp/docrest/open/file/getToken", None).await?;
        let token = token_response
            .data
            .ok_or_else(|| ChachaError::Custom("No token in response".to_string()))?;

        // Read file
        let file_content = fs::read(file_path).await?;

        // Create multipart form
        let file_part = multipart::Part::bytes(file_content)
            .file_name(file_name.to_string())
            .mime_str("application/octet-stream")?;

        let form = multipart::Form::new()
            .part("file", file_part)
            .text("token", token);

        // Upload
        let response = self
            .client
            .post(&self.config.tt_robot.upload_url)
            .multipart(form)
            .send()
            .await?;

        let response_text = response.text().await?;
        debug!("Upload response: {}", response_text);

        let upload_response: TTResponse<Vec<UploadFileResponse>> =
            serde_json::from_str(&response_text)?;

        if let Some(error) = upload_response.message {
            if !error.is_empty() {
                return Err(ChachaError::TTRobotApi(error));
            }
        }

        upload_response
            .data
            .and_then(|mut v| v.pop())
            .ok_or_else(|| ChachaError::Custom("Upload failed".to_string()))
    }

    pub async fn send_file(&self, who: &str, file_path: &str, receive_type: &str) -> Result<()> {
        let uploaded = self.upload_file(file_path).await?;

        let body = json!({
            "msg": {
                "imageId": uploaded.file_id,
                "name": uploaded.file_name,
                "size": uploaded.length,
                "imageType": uploaded.file_name.split('.').last().unwrap_or("txt"),
                "ftype": 0
            },
            "from": {
                "pub": self.config.tt_robot.robot_id
            },
            "to": {
                "receiveId": who,
                "receiveType": receive_type
            },
            "type": 8
        });

        let _response: TTResponse<serde_json::Value> =
            self.request("POST", "/oppo-mtp/oppo-robot/messages/send", Some(body)).await?;

        Ok(())
    }

    pub async fn send_one_file(&self, who: &str, file_path: &str) -> Result<()> {
        self.send_file(who, file_path, "1").await
    }

    pub async fn reply_file(&self, group_id: &str, message_id: &str, file_path: &str) -> Result<()> {
        let uploaded = self.upload_file(file_path).await?;

        let body = json!({
            "msg": {
                "imageId": uploaded.file_id,
                "name": uploaded.file_name,
                "size": uploaded.length,
                "imageType": uploaded.file_name.split('.').last().unwrap_or("txt"),
                "ftype": 0
            },
            "from": {
                "pub": self.config.tt_robot.robot_id
            },
            "groupId": group_id,
            "messageId": message_id,
            "type": 8
        });

        let _response: TTResponse<serde_json::Value> =
            self.request("POST", "/oppo-mtp/oppo-robot/messages/reply", Some(body)).await?;

        Ok(())
    }

    pub async fn download_file(&self, file_id: &str, folder: &str) -> Result<(String, String)> {
        // Get download token
        let token_response: TTResponse<String> =
            self.request("GET", "/oppo-mtp/docrest/open/downloadfile/getToken", None).await?;
        let token = token_response
            .data
            .ok_or_else(|| ChachaError::Custom("No token in response".to_string()))?;

        // Download file
        let url = format!(
            "https://mtp.myoas.com/docrest/open/downloadfile?fileId={}&token={}",
            file_id, token
        );

        let response = self.client.post(&url).send().await?;

        // Extract filename from Content-Disposition
        let content_disposition = response
            .headers()
            .get(header::CONTENT_DISPOSITION)
            .and_then(|v| v.to_str().ok())
            .ok_or_else(|| ChachaError::Custom("No Content-Disposition header".to_string()))?;

        let file_name = if let Some(start) = content_disposition.find("filename*=UTF-8''") {
            let encoded_name = &content_disposition[start + 17..];
            urlencoding::decode(encoded_name)
                .map_err(|_| ChachaError::Custom("Failed to decode filename".to_string()))?
                .to_string()
        } else {
            format!("download_{}", file_id)
        };

        // Save file
        let cache_folder = Path::new(&self.config.paths.cache_dir).join(folder);
        fs::create_dir_all(&cache_folder).await?;

        let file_path = cache_folder.join(&file_name);
        let content = response.bytes().await?;
        fs::write(&file_path, content).await?;

        info!("File downloaded: {:?}", file_path);

        Ok((
            file_name,
            file_path.to_str().unwrap_or_default().to_string(),
        ))
    }
}

