use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TTSender {
    #[serde(rename = "userName")]
    pub user_name: String,
    #[serde(rename = "userCode")]
    pub user_code: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TTMessage {
    #[serde(rename = "sendTime")]
    pub send_time: i64,
    #[serde(rename = "groupType")]
    pub group_type: i32,
    #[serde(rename = "messageType")]
    pub message_type: String,
    pub content: serde_json::Value,
    #[serde(rename = "groupName", skip_serializing_if = "Option::is_none")]
    pub group_name: Option<String>,
    #[serde(rename = "groupId", skip_serializing_if = "Option::is_none")]
    pub group_id: Option<String>,
    #[serde(rename = "messageId", skip_serializing_if = "Option::is_none")]
    pub message_id: Option<String>,
    #[serde(rename = "replyContent", skip_serializing_if = "Option::is_none")]
    pub reply_content: Option<String>,
    #[serde(rename = "replyParam", skip_serializing_if = "Option::is_none")]
    pub reply_param: Option<serde_json::Value>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TTEvent {
    pub sender: Option<TTSender>,
    pub message: Option<TTMessage>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TTWebhook {
    pub event: TTEvent,
    pub header: serde_json::Value,
}

#[derive(Debug, Clone)]
pub struct TTMsg {
    pub sender: TTSender,
    pub message_id: Option<String>,
    pub group_id: Option<String>,
    pub group_name: Option<String>,
    pub reply_content: Option<String>,
    pub is_group: bool,
    pub is_file: bool,
    pub is_text: bool,
    pub text: Option<String>,
    pub file_id: Option<String>,
    pub file_name: Option<String>,
    pub file_size: Option<i64>,
    pub is_efficient: bool,
    pub send_time: i64,
}

impl TTMsg {
    pub fn from_webhook(webhook: TTWebhook) -> Option<Self> {
        let event = webhook.event;
        
        let sender = event.sender?;
        let message = event.message?;

        // Ignore revoke messages
        if message.message_type == "9" {
            return None;
        }

        let is_group = message.group_type == 2;
        let mut is_file = message.message_type == "8";
        let is_text = message.message_type == "1";

        let mut file_id = None;
        let mut file_name = None;
        let mut file_size = None;
        let mut text = None;

        // Handle reply with file
        if let Some(reply_param) = &message.reply_param {
            if let Some(fid) = reply_param.get("file_id").and_then(|v| v.as_str()) {
                is_file = true;
                file_id = Some(fid.to_string());
                file_name = message.reply_content.clone();
            }
        }

        // Parse content
        if is_group {
            // Group message
            if let Some(text_content) = message.content.get("text").and_then(|v| v.as_str()) {
                text = Some(text_content.trim().to_string());
            }
            if let Some(content_array) = message.content.get("content").and_then(|v| v.as_array()) {
                let mut text_parts = Vec::new();
                for item in content_array {
                    if let Some(t) = item.get("text").and_then(|v| v.as_str()) {
                        text_parts.push(t.trim().to_string());
                    }
                }
                if !text_parts.is_empty() {
                    let combined = text_parts.join(" ");
                    text = Some(if let Some(existing) = text {
                        format!("{} {}", existing, combined)
                    } else {
                        combined
                    });
                }
            }
        } else {
            // Direct message
            if is_file {
                file_id = message.content.get("imageId").and_then(|v| v.as_str()).map(String::from);
                file_size = message.content.get("size").and_then(|v| v.as_i64());
                file_name = message.content.get("name").and_then(|v| v.as_str()).map(String::from);
            }
            if is_text {
                text = message.content.get("text").and_then(|v| v.as_str()).map(|s| s.trim().to_string());
            }
        }

        Some(TTMsg {
            sender,
            message_id: message.message_id,
            group_id: message.group_id,
            group_name: message.group_name,
            reply_content: message.reply_content,
            is_group,
            is_file,
            is_text,
            text,
            file_id,
            file_name,
            file_size,
            is_efficient: true,
            send_time: message.send_time,
        })
    }
}

#[derive(Debug, Serialize)]
pub struct TTSendRequest {
    pub msg: serde_json::Value,
    pub from: TTFrom,
    pub to: TTTo,
    #[serde(rename = "type")]
    pub msg_type: i32,
}

#[derive(Debug, Serialize)]
pub struct TTReplyRequest {
    pub msg: serde_json::Value,
    pub from: TTFrom,
    #[serde(rename = "groupId")]
    pub group_id: String,
    #[serde(rename = "messageId")]
    pub message_id: String,
    #[serde(rename = "type")]
    pub msg_type: i32,
}

#[derive(Debug, Serialize)]
pub struct TTFrom {
    pub pub_: String,
}

#[derive(Debug, Serialize)]
pub struct TTTo {
    #[serde(rename = "receiveId")]
    pub receive_id: String,
    #[serde(rename = "receiveType")]
    pub receive_type: String,
}

#[derive(Debug, Deserialize)]
pub struct TTResponse<T> {
    pub code: i32,
    pub data: Option<T>,
    pub message: Option<String>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct UploadFileResponse {
    #[serde(rename = "fileName")]
    pub file_name: String,
    #[serde(rename = "fileId")]
    pub file_id: String,
    pub length: i64,
}

