use proc_macro::TokenStream;
use quote::quote;
use syn::{parse_macro_input, ItemFn, LitStr, LitInt, parse::Parse, parse::ParseStream, Token};

/// Action 注解参数
struct ActionArgs {
    pattern: LitStr,
    desc: LitStr,
    priority: Option<LitInt>,
}

impl Parse for ActionArgs {
    fn parse(input: ParseStream) -> syn::Result<Self> {
        let pattern: LitStr = input.parse()?;
        input.parse::<Token![,]>()?;
        let desc: LitStr = input.parse()?;
        
        let priority = if input.parse::<Token![,]>().is_ok() {
            Some(input.parse()?)
        } else {
            None
        };

        Ok(ActionArgs {
            pattern,
            desc,
            priority,
        })
    }
}

/// # Action 注解宏
/// 
/// 用法：
/// ```rust
/// #[action(r"loggit .*", "Git日志查询", -1)]
/// async fn git_log_action(msg: TTMsg) -> Result<()> {
///     // 处理逻辑
/// }
/// ```
#[proc_macro_attribute]
pub fn action(args: TokenStream, input: TokenStream) -> TokenStream {
    let args = parse_macro_input!(args as ActionArgs);
    let input_fn = parse_macro_input!(input as ItemFn);

    let fn_name = &input_fn.sig.ident;
    let fn_vis = &input_fn.vis;
    let fn_block = &input_fn.block;
    let fn_attrs = &input_fn.attrs;
    
    let pattern = args.pattern;
    let desc = args.desc;
    let priority = args.priority.map(|p| quote! { #p }).unwrap_or(quote! { 1 });

    let expanded = quote! {
        #(#fn_attrs)*
        #fn_vis async fn #fn_name(msg: chacha::tt_robot::TTMsg) -> chacha::error::Result<()> {
            use tracing::{info, error};
            use std::time::Instant;

            let start = Instant::now();
            info!("👇👇👇 开始执行 action: {} - {}", #desc, #pattern);
            
            let result: chacha::error::Result<()> = async #fn_block.await;
            
            let elapsed = start.elapsed();
            match &result {
                Ok(_) => info!("👆👆👆 完成 action: {} - 耗时: {:.2}s", #desc, elapsed.as_secs_f64()),
                Err(e) => error!("❌❌❌ 失败 action: {} - 错误: {} - 耗时: {:.2}s", #desc, e, elapsed.as_secs_f64()),
            }
            
            result
        }

        // 自动注册函数
        #[allow(non_snake_case)]
        mod __register {
            use super::*;
            
            #[::chacha::ctor::ctor]
            fn register() {
                use chacha::action::registry::{register_action, ActionInfo};
                use regex::Regex;
                use std::sync::Arc;

                let pattern = Regex::new(#pattern).expect("Invalid regex pattern");
                let handler = Arc::new(move |msg: chacha::tt_robot::TTMsg| {
                    Box::pin(super::#fn_name(msg))
                        as std::pin::Pin<
                            Box<dyn std::future::Future<Output = chacha::error::Result<()>> + Send>,
                        >
                });

                let action = ActionInfo {
                    pattern,
                    desc: #desc.to_string(),
                    priority: #priority,
                    handler,
                };

                register_action(action);
            }
        }
    };

    TokenStream::from(expanded)
}

/// # 重试注解
/// 
/// 用于处理 token 过期等需要重试的场景
/// 
/// 用法：
/// ```rust
/// #[retry_on_token_error]
/// async fn get_phone_log(host: &str, fid: &str) -> Result<String> {
///     // 如果返回 TokenError，会自动重新登录后重试
/// }
/// ```
#[proc_macro_attribute]
pub fn retry_on_token_error(_args: TokenStream, input: TokenStream) -> TokenStream {
    let input_fn = parse_macro_input!(input as ItemFn);

    let fn_name = &input_fn.sig.ident;
    let fn_vis = &input_fn.vis;
    let fn_inputs = &input_fn.sig.inputs;
    let fn_output = &input_fn.sig.output;
    let fn_block = &input_fn.block;
    let fn_attrs = &input_fn.attrs;

    // 提取参数名
    let param_names: Vec<_> = fn_inputs.iter().filter_map(|arg| {
        if let syn::FnArg::Typed(pat_type) = arg {
            if let syn::Pat::Ident(ident) = &*pat_type.pat {
                Some(&ident.ident)
            } else {
                None
            }
        } else {
            None
        }
    }).collect();

    let expanded = quote! {
        #(#fn_attrs)*
        #fn_vis async fn #fn_name(#fn_inputs) #fn_output {
            use tracing::{warn, info};
            use chacha::error::ChachaError;

            // 创建内部实现函数
            async fn __inner_impl(#fn_inputs) #fn_output {
                #fn_block
            }

            // 第一次尝试
            match __inner_impl(#(#param_names),*).await {
                Ok(result) => Ok(result),
                Err(ChachaError::TokenError) => {
                    warn!("检测到 Token 错误，尝试重新登录...");
                    
                    // 执行重新登录逻辑
                    if let Err(e) = chacha::auth::refresh_login().await {
                        error!("重新登录失败: {}", e);
                        return Err(ChachaError::LoginError(format!("重新登录失败: {}", e)));
                    }
                    
                    info!("重新登录成功，重试操作...");
                    
                    // 重试
                    __inner_impl(#(#param_names),*).await
                }
                Err(e) => Err(e),
            }
        }
    };

    TokenStream::from(expanded)
}

