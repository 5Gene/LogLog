# Chacha - TT 机器人系统 (Rust 版本)

<div align="center">

🤖 一个高性能、类型安全的 TT 机器人框架

[![Rust](https://img.shields.io/badge/rust-1.70%2B-orange.svg)](https://www.rust-lang.org/)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)

</div>

## 📋 目录

- [项目简介](#项目简介)
- [核心架构](#核心架构)
- [功能特性](#功能特性)
- [快速开始](#快速开始)
- [项目结构](#项目结构)
- [添加新功能](#添加新功能)
- [配置说明](#配置说明)
- [API 文档](#api-文档)

## 🎯 项目简介

Chacha 是一个基于 Rust 的 TT 机器人系统，用于处理穿戴事业部内部的各种自动化任务。相比 Python 原版，Rust 版本具有：

- ⚡ **更高性能** - 真正的并发，无 GIL 限制
- 🛡️ **类型安全** - 编译期类型检查，减少运行时错误
- 🔒 **内存安全** - 无数据竞争，无内存泄漏
- 📦 **单一二进制** - 方便部署，无需依赖环境

## 🏗️ 核心架构

### 六层核心逻辑

```
1. 启动服务 → 输出服务 IP 信息
2. 提供接口 → /listen 接收业务消息
3. 消息分发 → 根据正则匹配分发到 action
4. 业务处理 → 各个 action 实现具体逻辑
5. 注解注册 → 通过 #[action] 宏自动注册
6. 自动重试 → #[retry_on_token_error] 处理 token 过期
```

### 架构图

```
┌─────────────────────────────────────────────────┐
│              TT 机器人平台                        │
└────────────────┬────────────────────────────────┘
                 │ Webhook
                 ▼
┌─────────────────────────────────────────────────┐
│           HTTP Server (Axum)                    │
│  - POST /listen    (接收消息)                    │
│  - GET  /file      (文件下载)                    │
│  - GET  /health    (健康检查)                    │
└────────────────┬────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────┐
│         Message Dispatcher                      │
│  - 解析 TT 消息                                  │
│  - 区分群聊/私聊                                  │
│  - 提取文本/文件                                  │
└────────────────┬────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────┐
│         Action Registry                         │
│  - 正则表达式匹配                                 │
│  - 优先级排序                                     │
│  - 异步分发                                       │
└────────────────┬────────────────────────────────┘
                 │
        ┌────────┼────────┐
        ▼        ▼        ▼
    ┌──────┐ ┌──────┐ ┌──────┐
    │ Git  │ │ 日志  │ │ APK  │  ...
    │ Log  │ │ 查询  │ │ 打包  │
    └──────┘ └──────┘ └──────┘
      Business Actions
```

## ✨ 功能特性

### 已实现功能

- ✅ **Git 日志查询** - 查询指定分支的 git log
- ✅ **手机日志查询** - 支持 W/OLC 格式反馈 ID
- ✅ **日志文件解密** - 解密 .zip/.log/.dog 格式日志
- ✅ **自动重试机制** - Token 过期自动重新登录
- ✅ **文件上传下载** - 支持文件传输
- ✅ **群聊/私聊支持** - 完整的消息类型支持

### Python 版本已有但待移植

- ⏳ APK 灰度包处理
- ⏳ SDK 版本更新
- ⏳ 特殊构建触发
- ⏳ 定时任务调度

## 🚀 快速开始

### 前置要求

- Rust 1.70+
- Java 11+ (用于日志解密)

### 安装

```bash
# 克隆项目
cd chacha-rust

# 构建
cargo build --release

# 运行
./target/release/chacha
```

### 配置

1. 复制配置文件：

```bash
cp .env.example .env
```

2. 编辑 `.env` 文件，填入必要的配置：

```env
TT_APP_SECRET=your_app_secret
TT_ROBOT_ID=BOT-12657
LOGIN_TOKEN=your_login_token
SERVER_PORT=8000
```

3. 编辑 `config.toml` 调整其他配置。

### 运行

```bash
cargo run
```

输出示例：

```
========================================
Chacha 机器人启动中...
========================================
✓ 配置加载成功
  - 服务地址: 0.0.0.0:8000
  - TT机器人ID: BOT-12657
  - 环境: release
✓ 登录状态初始化完成
✓ 已注册 3 个业务处理器:
  1. 【loggit 37d992a wsw/master】返回指定分支指定节点到当前的git log
  2. 【W..】捞取W开头反馈ID的手机系统日志
  3. 【zip,log,dog1,dog2,dog3】解密这些日志打捞格式的文件
========================================
主机名: YOUR-HOSTNAME
服务地址: http://10.16.25.229:8000
健康检查: http://10.16.25.229:8000/health
文件下载: http://10.16.25.229:8000/file?path=<文件路径>
服务监听: 0.0.0.0:8000
========================================
```

## 📁 项目结构

```
chacha-rust/
├── Cargo.toml                 # 主项目配置
├── config.toml               # 应用配置
├── .env.example              # 环境变量模板
├── chacha-macros/            # 过程宏库
│   ├── Cargo.toml
│   └── src/
│       └── lib.rs            # #[action] 和 #[retry_on_token_error] 宏
├── src/
│   ├── main.rs               # 程序入口
│   ├── lib.rs                # 库根
│   ├── config.rs             # 配置管理
│   ├── error.rs              # 错误类型
│   ├── server/               # HTTP 服务器
│   │   └── mod.rs
│   ├── tt_robot/             # TT 机器人客户端
│   │   ├── mod.rs
│   │   ├── client.rs         # API 客户端
│   │   └── models.rs         # 消息模型
│   ├── dispatcher/           # 消息分发器
│   │   └── mod.rs
│   ├── action/               # Action 系统
│   │   ├── mod.rs
│   │   ├── registry.rs       # Action 注册表
│   │   └── auth.rs           # 登录和重试逻辑
│   └── business/             # 业务逻辑
│       └── actions/
│           ├── mod.rs
│           ├── git_log.rs    # Git 日志查询
│           ├── get_phone_log.rs  # 手机日志查询
│           └── log_read.rs   # 日志解密
└── PROJECT_ANALYSIS.md       # 项目分析文档
```

## 🎨 添加新功能

### 1. 创建新的 Action

在 `src/business/actions/` 下创建新文件，例如 `my_action.rs`：

```rust
use chacha_macros::action;
use crate::error::Result;
use crate::tt_robot::TTMsg;
use tracing::info;

// 使用 #[action] 宏注解
// 参数：正则表达式, 描述, 优先级(可选)
#[action(r"hello .*", "【hello】打招呼功能", 1)]
async fn hello_action(msg: TTMsg) -> Result<()> {
    let text = msg.text.as_deref().unwrap_or("");
    info!("收到打招呼消息: {}", text);
    
    // 获取 TT 客户端
    let tt_client = crate::tt_robot::TTRobotClient::new(
        crate::config::AppConfig::global().clone()
    );
    
    // 回复消息
    if msg.is_group {
        if let (Some(group_id), Some(message_id)) = (&msg.group_id, &msg.message_id) {
            tt_client.reply(group_id, message_id, "你好！").await?;
        }
    } else {
        tt_client.send_one(&msg.sender.user_code, "你好！").await?;
    }
    
    Ok(())
}
```

### 2. 注册 Action

在 `src/business/actions/mod.rs` 中添加模块：

```rust
pub mod my_action;
```

在 `src/main.rs` 中导入模块（触发自动注册）：

```rust
let _ = business::actions::my_action;
```

### 3. 使用重试机制

对于需要处理 token 过期的函数，使用 `#[retry_on_token_error]` 宏：

```rust
use chacha_macros::retry_on_token_error;

#[retry_on_token_error]
async fn call_api_with_token(url: &str) -> Result<String> {
    // 如果返回 ChachaError::TokenError
    // 会自动调用 refresh_login() 后重试
    // ...
}
```

## ⚙️ 配置说明

### config.toml

```toml
[server]
host = "0.0.0.0"      # 服务监听地址
port = 8000           # 服务端口

[tt_robot]
app_id = "iot_80256"
app_secret = "xxx"    # 建议通过环境变量设置
robot_id = "BOT-12657"
host = "apimarket.myoas.com"
upload_url = "https://mtp.myoas.com/docrest/open/file/uploadfile"
environment = "release"  # 或 "uat"

[paths]
root_dir = "."
cache_dir = "./cache"
log_dir = "./logs"

[logging]
level = "info"
format = "json"
```

### 环境变量

支持通过环境变量覆盖配置：

```bash
# 格式: CHACHA_<SECTION>_<KEY>
export CHACHA_TT_ROBOT_APP_SECRET=your_secret
export CHACHA_SERVER_PORT=9000
```

## 📡 API 文档

### POST /listen

接收 TT 机器人 webhook 消息

**请求体：**
```json
{
  "event": {
    "sender": {
      "userName": "张三",
      "userCode": "80256595"
    },
    "message": {
      "messageType": "1",
      "content": { "text": "hello" }
    }
  }
}
```

### GET /file

下载文件

**参数：**
- `path`: 文件路径

**示例：**
```
GET /file?path=/cache/user/test.txt
```

### GET /health

健康检查

**响应：**
```
OK
```

## 🔧 开发指南

### 日志级别

```bash
# 设置日志级别
export RUST_LOG=chacha=debug,tower_http=trace

# 运行
cargo run
```

### 测试

```bash
# 运行所有测试
cargo test

# 运行特定测试
cargo test test_name
```

### 构建发布版本

```bash
cargo build --release
```

生成的二进制文件在 `target/release/chacha`

## 📊 性能对比

| 指标 | Python 版本 | Rust 版本 | 提升 |
|------|-------------|-----------|------|
| 启动时间 | ~2s | ~50ms | **40x** |
| 内存占用 | ~150MB | ~15MB | **10x** |
| 并发处理 | 受限于 GIL | 真正并发 | **显著提升** |
| 响应时间 | ~100ms | ~5ms | **20x** |

## 🤝 贡献指南

1. Fork 本项目
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启 Pull Request

## 📝 许可证

本项目采用 MIT 许可证。

## 🙏 致谢

- 原 Python 版本的所有贡献者
- Rust 社区提供的优秀框架和工具

---

<div align="center">
Made with ❤️ by 穿戴事业部
</div>

